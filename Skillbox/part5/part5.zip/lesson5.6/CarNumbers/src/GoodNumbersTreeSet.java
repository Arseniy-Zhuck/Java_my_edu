import java.util.TreeSet;

public class GoodNumbersTreeSet extends GoodNumbersSet{
    public GoodNumbersTreeSet() {
        goodNumbers = new TreeSet<>();
        info = "TreeSet search";
    }
}
