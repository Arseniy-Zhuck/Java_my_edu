import java.util.HashSet;

public class GoodNumbersHashSet extends GoodNumbersSet{
    public GoodNumbersHashSet() {
        goodNumbers = new HashSet<>();
        info = "HashSet search";
    }
}
