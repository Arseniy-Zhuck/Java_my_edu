import org.javagram.TelegramApiBridge;
import org.javagram.response.AuthAuthorization;
import org.javagram.response.AuthCheckedPhone;
import org.javagram.response.AuthSentCode;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TelegaTest {
    public static void main(String[] args) throws IOException {

        String testAddr = "149.154.167.40:443";
        String prodAddr = "149.154.167.50:443";
        Integer appId = 276685;
        String appHash = "982c56d252af8ee74195134bc509cee1";
        String phoneNumber = "79035386295";

        TelegramApiBridge bridge = new TelegramApiBridge(prodAddr,
                appId, appHash);
        System.out.println("Please type your phone number:");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        AuthCheckedPhone checkPhone = bridge.authCheckPhone(phoneNumber);

        if (checkPhone.isRegistered()) {
            bridge.authSendCode(phoneNumber);
            System.out.println("Please type confirm code");
            String code = new BufferedReader(new InputStreamReader(System.in)).readLine();
            AuthAuthorization authAuthorization = bridge.authSignIn(code);
            String name = authAuthorization.getUser().getFirstName() + " " + authAuthorization.getUser().getLastName();
            System.out.println("Authorized name: " + name.trim());
        } else {
            System.out.println("Please type registered number");
        }

    }
}
