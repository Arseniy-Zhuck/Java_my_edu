package core;

/**
 * Created by Danya on 24.08.2015.
 */
public class WeightMeter
{
    public static Double getWeight(Car car)
    {
        return car.getWeight();
    }
}