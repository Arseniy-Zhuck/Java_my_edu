import javax.swing.*;

public class Form {
    private JPanel rootPanel;
    private JTextField tFSurname;
    private JLabel lblSurname;
    private JLabel lblName;
    private JTextField tFName;
    private JLabel lblLastName;
    private JTextField tFLastName;
    private JLabel lblDateOfBirth;
    private JTextField tFDateOfBirth;
    private JLabel lblCity;
    private JTextField tFCity;
    private JButton btnConfirm;

    public JPanel getRootPanel() {
        return rootPanel;
    }
}
