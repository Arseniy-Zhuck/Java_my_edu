public interface Vertebrate extends Comparable<Vertebrate> {
    void move();
    void moveForALittle();
    void eat();
    void voice();
    double getWeight();
}
