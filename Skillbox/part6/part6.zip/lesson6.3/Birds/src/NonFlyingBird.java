public abstract class NonFlyingBird extends Bird {
    public NonFlyingBird(String name) {
        super(name);
    }



}
