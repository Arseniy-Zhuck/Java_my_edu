public class NonFlyingBird extends Bird {
    public NonFlyingBird(String name) {
        super(name);
    }



}
