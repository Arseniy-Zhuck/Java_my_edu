public interface Duck {
    void swim(double meters);
    void catchFish();
}
