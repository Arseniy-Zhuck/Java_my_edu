package materia;

public enum METAL implements MaterialDetails {
    /*
    Cast iron
    Carbon (tool) steel
    Alloy steel
    Aluminum
            duralumin */
    CAST_IRON,
    CARBON_STEEL,
    ALLOY_STEEL,
    ALUMINIUM,
    DURALUMIN
}
