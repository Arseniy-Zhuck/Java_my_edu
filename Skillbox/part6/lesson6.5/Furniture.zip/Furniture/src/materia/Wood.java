package materia;

public enum Wood implements MaterialDetails {
    /* Pine
Oak
Ash
Maple
Beech
Nut */
    PINE,
    OAK,
    ASH,
    MAPLE,
    BEECH,
    NUT
}
