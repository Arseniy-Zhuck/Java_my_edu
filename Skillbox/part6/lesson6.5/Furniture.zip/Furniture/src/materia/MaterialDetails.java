package materia;

public interface MaterialDetails {
}
