package materia;

public enum Plastic implements MaterialDetails {
    HPL,
    CPL
}
