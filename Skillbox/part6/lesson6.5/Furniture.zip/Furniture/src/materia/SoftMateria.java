package materia;

public enum SoftMateria {
    SYNTHETIC_WINTERIZER,//synthetic winterizer,foam rubber, cotton wool, sea grass and horse hair
    FOAM_RUBBER,
    COTTON_WOOL,
    SEA_GRASS,
    HORSE_HAIR
}
