package materia;

public enum Chipboard implements MaterialDetails {
    /* Pine
alder, aspen, poplar, maple birch */
    PINE,
    ALDER,
    ASPEN,
    POPLAR,
    MAPLE,
    BIRCH
}
