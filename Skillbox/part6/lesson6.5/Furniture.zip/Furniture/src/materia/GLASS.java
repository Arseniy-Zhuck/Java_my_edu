package materia;

public enum GLASS implements MaterialDetails {
    /* Clear glass
Frosted glass -
Patterned glass
Mirror glass.
Colored glass -
Tinted */
    CLEAR,
    FROSTED,
    PATTERNED,
    MIRROR,
    COLORED,
    TINTED
}
