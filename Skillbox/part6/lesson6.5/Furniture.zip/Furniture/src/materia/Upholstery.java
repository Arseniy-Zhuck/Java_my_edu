package materia;

public enum Upholstery {
    CLOTH,
    LEATHER,
    ECO_LEATHER,
    LEATHERETTE
}
