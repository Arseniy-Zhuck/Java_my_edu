package materia;

public enum EcoLeather implements MaterialDetails {
    OREGON,
    ALBA,
    COMPANION,
    DOLLARO
}
