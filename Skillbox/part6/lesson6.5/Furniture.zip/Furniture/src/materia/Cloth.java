package materia;

public enum Cloth implements MaterialDetails {
    /* jacquard.
    tapestry.
            shenill. ...
    flock. ...
    velours. ...
    matting. ...
    velvet. */

    JACQUARD,
    TAPESTRY,
    SHENILL,
    FLOCK,
    VELOURS,
    MATTING,
    VELVET
}
