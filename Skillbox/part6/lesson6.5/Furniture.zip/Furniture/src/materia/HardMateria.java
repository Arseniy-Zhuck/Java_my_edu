package materia;
public enum HardMateria {
    METAL,
    WOOD,
    CHIPBOARD,
    PLASTIC,
    GLASS
}
