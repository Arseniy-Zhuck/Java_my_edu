package materia;

public enum LEATHER implements MaterialDetails {
    FULL_GRAIN,
    HALF_GRAIN,
    BUFFERED_GRAIN
}
