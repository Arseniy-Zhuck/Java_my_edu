package form;

public interface Form {
    double getArea();
    double getPerimeter();
    String getSizes();
}
